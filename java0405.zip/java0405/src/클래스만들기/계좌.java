package 클래스만들기;

public class 계좌 {
	String 이름;
	String 계좌이름;
	int 금액;
	
	public void 적금하다() {
		System.out.println("이름= " + 이름 + ", " + "계좌이름= " + 계좌이름 + ", " + "금액= " + 금액);
	}
	public void 예금하다() {
		System.out.println("이름= " + 이름 + ", " + "계좌이름= " + 계좌이름 + ", " + "금액= " + 금액);
	}
}
