package 클래스만들기;

public class 우리집계좌만들기 {

	public static void main(String[] args) {
		계좌 account = new 계좌();
		account.이름 = "홍길동";
		account.계좌이름 = "튼튼적금";
		account.금액 = 1000;
		
		account.적금하다();
		
		
		계좌 account1 = new 계좌();
		account1.이름 = "박길동";
		account1.계좌이름 = "튼튼예금";
		account1.금액 = 2000;
		
		account1.예금하다();
		
		
		계좌 account2 = new 계좌();
		account2.이름 = "홍기사";
		account2.계좌이름 = "다음적금";
		account2.금액 = 3000;
		
		account2.적금하다();

	}

}
